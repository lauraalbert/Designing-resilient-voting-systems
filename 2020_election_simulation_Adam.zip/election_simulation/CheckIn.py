'''
Created on Jul 7, 2020

@author: apsch
'''

from numpy import average

index = 0
checkIns = []


def create(n):
    for i in range(n):
        checkIns.append(CheckIn())
    return

def reset():
    global index
    global checkIns
    CheckIn.ID = 0
    checkIns = []
    index = 0

def isAvailableResource():
    for c in checkIns:
        if c.isAvailable():
            return True
    return False

def getAvailableResource():
    '''
    This returns an available object
    '''
    for c in checkIns:
        if c.isAvailable():
            return c
    return None

def getAvgUtil():
    return average([c.uptime/(c.uptime+c.downtime) for c in checkIns])

class CheckIn():
    ID = 0
    def __init__(self):
        self.ID = CheckIn.ID
        CheckIn.ID += 1
        self.uptime = 0
        self.downtime = 0
        self.timer = 0 # This will start the temporary timing
        self.siezed = False
        
    def sieze(self,time):
        if self.siezed:
            raise Exception(f"CheckIn {self.ID} already siezed.")
        
        # This will add time to the downtime
        self.downtime += time - self.timer
        self.timer = time
        self.siezed = True
        
    def release(self,time):
        if not self.siezed:
            raise Exception(f"CheckIn {self.ID} not siezed.")
        self.uptime += time - self.timer
        self.timer = time
        self.siezed = False
    
    def isAvailable(self):
        return not self.siezed
    def __str__(self):
        return f"C{self.ID}"
    def __repr__(self):
        return f"C{self.ID}"
        