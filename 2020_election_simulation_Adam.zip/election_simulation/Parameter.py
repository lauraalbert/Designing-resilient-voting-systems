'''
Created on Jul 7, 2020

@author: apsch
'''

'''
Use this to set the parameters for the simulation
'''

import numpy as np

####
# Polling Location Params
####
# Let each of these be lists so we can iterate through
voter_turnout = [.572] # percent of potential voters who vote
early_voting = [.310] # percent of those who vote who vote early
style = ["D"] # either "A" or "D" for arena or distributed
priority_frac = [.138] # Fraction of arrivals which are of high priority
# cap_scale = [0.5] #,0.5
n_replications = 50 # 
# capacity = 10 # 5000000
####
# Functions 
####
# def interarrival(rate,extra = None):
#     return np.random.exponential(1/rate)
# 
# def checkInDuration():
#     return np.random.triangular(.5,1,1.5)
# 
# def votingDuration():
#     return np.random.lognormal(1.7042,0.4406)
# 
# def submitDuration():
#     return np.random.triangular(.25,.5,.75)
    

'''
These functions update/create the necessary additional params
'''

file = "InputData\\LocationData\\"
if style == "A":
    file += "Arena.csv"
elif style == "D":
    file += "Distributed.csv"
    

####
# Reading in the info from the file
####

    
# Setting the params for the 5 polling locations
n_pollingLocs = 5

n_voters = {} # Number of voters at each location
n_machines = {} #number of machines at each location

for i in range(n_pollingLocs):
    n_voters[i] = 0


for i in range(n_pollingLocs):
    pass
    



