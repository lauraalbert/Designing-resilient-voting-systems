'''
Created on Jul 7, 2020

@author: apsch
'''

import random
import heapq
from numpy import average

voters = []
index = 0

def reset():
    global voters
    global index
    voters = []
    index = 0
    Voter.ID = 0
    
def votersDone():
    return index == len(voters)

def nextVoter():
    if index == len(voters):
        return None
    v = voters[index]
    index += 1
    return v

def voterTimePeak():
    return voters[index].arrivalTime

def getAvgWait(priority = None):
    if priority == None:
        return average([v.startCheckIn-v.arrivalTime for v in voters])
    return average([v.startCheckIn-v.arrivalTime for v in voters if v.priority == priority])
def getMaxWait(priority = None):
    if priority == None:
        return max([v.startCheckIn-v.arrivalTime for v in voters])
    return max([v.startCheckIn-v.arrivalTime for v in voters if v.priority == priority])

def getAvgSojourn(priority = None):
    if priority == None:
        return average([v.finishTime-v.arrivalTime for v in voters])
    return average([v.finishTime-v.arrivalTime for v in voters if v.priority == priority] )
def getMaxSojourn(priority = None):
    if priority == None:
        return max([v.finishTime-v.arrivalTime for v in voters])
    return max([v.finishTime-v.arrivalTime for v in voters if v.priority == priority] )
    
def getPropTmin(T):
    return sum([1 for v in voters if v.startCheckIn - v.arrivalTime >= T])/len(voters)

def getMaxPropTmin(T):
    tmp = []
    for v in voters:
        if v.startCheckIn - v.arrivalTime >= T:
            tmp.append(1)
        else:
            tmp.append(0)
    return max(tmp)

def getAvgTimeInside():
    return average([v.finishTime-v.startCheckIn for v in voters])
def getMaxTimeInside():
    return max([v.finishTime-v.startCheckIn for v in voters])
def readVoters(wards, rep,info = None):
    '''
    Reads in the voters corresponding to
    the [wards] provided and the [rep]th 
    replication
    '''
    global voters
#     votersref = [] # This will store the voters and their arrival
#                   # time so we can sort later
#     voters
    if info == None:
        raise Exception("No info provided to read voters")
    
    vt,ev,fp,ppe,reject,style = info
    
    for ward_n in wards:
        with open(f"InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}\\r{rep}\\w{ward_n}.csv","r") as f:
            count = 0
            for row in f.readlines():
                if count == 0:
                    pass
                else:
                    row = row.split(",")
                    if style == "A":
                        if float(row[11]) < reject:
                            newVoter = Voter()
                            # Setting the known params
                            #ID    priority    ArrivalTime    checkInDur    serviceDur    submitDur
                            newVoter.priority = int(row[1])
                            newVoter.ID = f"{int(row[0])}w{ward_n}"
                            newVoter.arrivalTime = float(row[2])
                            if ppe == "-":
                                newVoter.checkInDuration = float(row[3])
                            elif ppe == "+":
                                newVoter.checkInDuration = float(row[4])
                            else:
                                raise Exception(f"{info[3]} not a recogniced PPE designation")
        #                     newVoter.checkInDuration = float(row[3])
                            newVoter.serviceDuration = float(row[5])
                            newVoter.submitDuration = float(row[6])
                            newVoter.cleanVoteDuration = float(row[7])
                            newVoter.cleanMachineDuration = float(row[8])
                            voters.append(newVoter)
        #                     heapq.heappush(voterspq,(newVoter.arrivalTime,newVoter))
                    elif style == "D":
                        if float(row[11]) >= reject:
                            newVoter = Voter()
                            # Setting the known params
                            #ID    priority    ArrivalTime    checkInDur    serviceDur    submitDur
                            newVoter.priority = int(row[1])
                            newVoter.ID = f"{int(row[0])}w{ward_n}"
                            newVoter.arrivalTime = float(row[2])
                            if ppe == "-":
                                newVoter.checkInDuration = float(row[3])
                            elif ppe == "+":
                                newVoter.checkInDuration = float(row[4])
                            else:
                                raise Exception(f"{info[3]} not a recogniced PPE designation")
        #                     newVoter.checkInDuration = float(row[3])
                            newVoter.serviceDuration = float(row[5])
                            newVoter.submitDuration = float(row[6])
                            newVoter.cleanVoteDuration = float(row[7])
                            newVoter.cleanMachineDuration = float(row[8])
                            voters.append(newVoter)
                    else:
                        raise Exception(f"Incorrect style {style} entered")
                count +=1  
#     
    votertimes = [v.arrivalTime for v in voters]
    voters = [x for _, x in sorted(zip(votertimes,voters), key=lambda pair: pair[0])]
#     print(voters)
#     print([v.arrivalTime for v in voters])
#     input()
#     while voterspq:
#         try:
#             next_item = heapq.heappop(voterspq)
#         except:
#             print(voterspq)
#             next_item = heapq.heappop(voterspq)
#             input()
#         voters.append(next_item[1])
    
    return True

def getVoters(time):
    return [v for v in voters if v.arrivalTime < time] 

class Voter:
    ID = 0
    def __init__(self):
        self.ID = Voter.ID
        Voter.ID += 1
        self.priority = None # Priority for priority queue
#         self.absentee = None  # Do they vote absentee?
        
        self.arrivalTime = -1 # What time do they arrive at
        self.finishTime = -1
#         self.sojournTime = -1 # Finish voting - arrival time
        
        self.startCheckIn = -1 # When they start checkIn
        self.checkInDuration = -1 # How long it takes to register
        
        self.startService = -1 # Time which they start service
        self.serviceDuration = -1 # How long will it take?
        self.cleanVoteDuration = -1 # How long does it take to clean
                    
        
        self.startSubmit = -1 # Time which they start service
        self.submitDuration = -1 # How long will it take?
        self.cleanMachineDuration = -1 # How long does it take to clean?
        
    def __repr__(self):
        return f"V{self.ID}"
    def __str__(self):
        return f"V{self.ID}"
    def __lt__(self, other):
        ward = int(self.ID.split("w")[1])
        num = int(self.ID.split("w")[0])
        if ward < int(other.ID.split("w")[1]):
            return True
        elif ward == int(other.ID.split("w")[1]):
            if num < int(other.ID.split("w")[0]):
                return True
        return False
        
        