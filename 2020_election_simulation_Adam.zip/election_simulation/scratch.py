'''
Created on Jul 8, 2020

@author: apsch
'''
import numpy as np
from numpy import average


r = 50/13/60

counts = []

for i in range(1000):
    time = 0
    count = 0
    while time < 780:
        t = np.random.exponential(1/r)
        time += t
        if time <= 780:
            count += 1
    counts.append(count)

print(average(counts))