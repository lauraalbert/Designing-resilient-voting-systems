'''
Created on Aug 7, 2020

@author: apsch
'''
import geopandas as gpd
from shapely.geometry import Point, Polygon
import geopy.distance
import numpy as np
random = np.random.RandomState(6)
mixed_random = np.random.RandomState(3)
def generateLatLon(ward):
    # The input ward will be one less as we start at 0
    ward = ward + 1
    
    # Setting projection info
    from pyproj import Proj
    myProj = Proj("+proj=lcc +lat_1=42.73333333333333 +lat_2=44.06666666666667 +lat_0=42 +lon_0=-90 +x_0=609601.2192024384 y_0=0 datum=NAD27 units=us-ft no_defs ellps=WGS84")
    
    
    #Reading in each of the polygons describing the wards
    poly = gpd.read_file("InputData\\Shapefile\\ward.shp")
    
    ###
    # Generating the coordinate and seeing if within the polygon
    #this is the row we are lookin at
    row = poly.loc[poly['WARD2012'] == ward]
    
    #Getting the bounding box so we can generate points within the shape
    minx, miny, maxx, maxy = row["geometry"].bounds.values[0]

    # Repeat samplings (accept reject) until we find a point within the boundary
    # of the same
    found_point = False
    while not found_point:
        #New point
        new_x = random.uniform(minx,maxx)
        new_y = random.uniform(miny,maxy)
        
        # Keeping point if within
        if row["geometry"].values[0].contains(Point(new_x,new_y)):
            found_point = True
    
    # Calculating Lat/Long
    lat,lon = myProj(new_x,new_y, inverse=True)
    
    return lon,lat
    
def wardDistance(ward, polls):
    '''
    This will randomize locations for each voting aged individual
    in the ward and calculate the Manhattan (l1) norm between the voter
    and each poll.
    
    Will return a dictionary with key = polls keys, value = tuple
    of distances to the poll key. Length of tuple will be the number
    of voting aged individuals in the ward. 
    '''
    
    assignment = {}
    
    # Read in the ward data and the number of voting aged individuals
    with open("InputData\\LocationData\\Ward.csv","r") as f:
        cou = 0
        for row in f.readlines():
            row = row.split(",")
            row[-1] = row[-1].replace("\n","")
            if cou > 0:
                if int(row[0]) == ward:
                    num_voters = int(row[1])    
                    assignment["A"] = int(row[4])
                    assignment["D"] = int(row[3])
    #                 assignment["M5"] = -1 if mixed_random < 0.05 else int(row[3]) 
    #                 assignment["M10"] = -1 if mixed_random < 0.1 else int(row[3]) 
            cou += 1
                
        
        
    distances = {}
    
    #Distance traveled for the arena
    distances["A"] = []
    distances["D"] = []
    
    ## Arena
    a_lon, a_lat = polls["A"][assignment["A"]]
    
    ## Distributed
    d_lon, d_lat = polls["D"][ward]
    
    for v in range(num_voters):
        lon, lat = generateLatLon(ward)
        
        #Distance to arena
        d = geopy.distance.distance((a_lon,a_lat),(lon,lat)).miles
        distances["A"].append(d)
        
        #Distance to distributed
        d = geopy.distance.distance((d_lon,d_lat),(lon,lat)).miles
        distances["D"].append(d)
    print(f"Finished ward {ward} with {num_voters} voters.")
    return distances

total_arena_distance = 0
total_distributed_distance = 0
total_number_of_voters = 0
max_distance_traveled_arena = -1
max_distance_traveled_distributed = -1
for w in range(327):
    polls = {} 
    
    #The poll locations for the arena style
    polls["A"] = {}
    with open("InputData\\LocationData\\ArenaCoordinates.csv","r") as f:
        cou = 0
        for row in f.readlines():
            row = row.split(",")
            row[-1] = row[-1].replace("\n","")
            polls["A"][int(row[0])] = (float(row[1]), float(row[2]))
    
    #The poll locations for the distributed style
    polls["D"] = {}
    with open("InputData\\LocationData\\DistributedCoordinates.csv","r") as f:
        cou = 0
        for row in f.readlines():
            row = row.split(",")
            row[-1] = row[-1].replace("\n","")
            polls["D"][int(row[0])] = (float(row[1]), float(row[2]))
            
    
    
    distances = wardDistance(w,polls)
    
    # Adding up all distance
    total_arena_distance += sum(distances["A"])
    total_distributed_distance += sum(distances["D"])
    total_number_of_voters += len(distances["A"])
    
    # Finding max distance and adding
    if len(distances["A"]) > 0:
        max_arena = max(distances["A"])
        max_distr = max(distances["D"])
        
        if max_arena > max_distance_traveled_arena:
            max_distance_traveled_arena = max_arena
            
        if max_distr > max_distance_traveled_distributed:
            max_distance_traveled_distributed = max_distr
    
    
    print(total_distributed_distance, total_arena_distance)
    
print(total_arena_distance)
print(total_distributed_distance)
print(total_number_of_voters)
print(max_distance_traveled_arena)
print(max_distance_traveled_distributed)



