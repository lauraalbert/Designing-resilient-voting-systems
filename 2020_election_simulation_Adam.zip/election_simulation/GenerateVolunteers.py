'''
Created on Jul 8, 2020

@author: apsch
'''

import numpy as np
import Parameter,os

import geopandas as gpd
from shapely.geometry import Point, Polygon

# def generateLatLon(ward, random):
#     
#     # Setting projection info
#     from pyproj import Proj
#     myProj = Proj("+proj=lcc +lat_1=42.73333333333333 +lat_2=44.06666666666667 +lat_0=42 +lon_0=-90 +x_0=609601.2192024384 y_0=0 datum=NAD27 units=us-ft no_defs ellps=WGS84")
#     
#     
#     #Reading in each of the polygons describing the wards
#     poly = gpd.read_file("..\\InputData\\Shapefile\\ward.shp")
#     
#     ###
#     # Generating the coordinate and seeing if within the polygon
#     #this is the row we are lookin at
#     row = poly.loc[poly['WARD2012'] == ward]
#     
#     #Getting the bounding box so we can generate points within the shape
#     minx, miny, maxx, maxy = row["geometry"].bounds.values[0]
# 
#     # Repeat samplings (accept reject) until we find a point within the boundary
#     # of the same
#     found_point = False
#     while not found_point:
#         #New point
#         new_x = random.uniform(minx,maxx)
#         new_y = random.uniform(miny,maxy)
#         
#         # Keeping point if within
#         if row["geometry"].values[0].contains(Point(new_x,new_y)):
#             found_point = True
#     
#     # Calculating Lat/Long
#     lon, lat = myProj(new_x,new_y, inverse=True)
#     
#     return lat, lon


ev =0.310   #Parameter.early_voting[0]
vt =0.572 #Parameter.voter_turnout[0]
fp = Parameter.priority_frac[0]

if not os.path.exists(f"..\\InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}"):
    os.mkdir(f"..\\InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}")
    
# n replication of the arrivals
n = 50
for rep in range(n):
    # making a directory for the replication
    if not os.path.exists(f"..\\InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}\\r{rep}"):
        os.mkdir(f"..\\InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}\\r{rep}")
    
    # simulating arrivals from individuals by each ward
    # we will join them together later. Poisson process merging, remains exponential
    # just with a higher rate
    #we read in the info from the ward file
    with open("..\\InputData\\LocationData\\Ward.csv","r") as f:
        cou = 0
        for row in f.readlines():
            if cou == 0:
                pass
                cou += 1
            else:
                
                row = row[:-1]
                row = row.split(",")
                
                for i in range(len(row)):
                    row[i] = int(row[i].strip())
                
                
                ward_n = row[0]+1
                # Common random number generator for when we compare different levels
                a_random = np.random.RandomState(seed = rep)
                b_random = np.random.RandomState(seed = rep+400*ward_n) # we use 400 as it is larger than 327
                h_random = np.random.RandomState(seed = rep+400*ward_n) # probably on different replications; want this to match b_random
                c_random = np.random.RandomState(seed = rep+2*400*ward_n) # otherwise at some point two of these
                d_random = np.random.RandomState(seed = rep+3*400*ward_n) # generators will have same stream
                e_random = np.random.RandomState(seed = rep+4*400*ward_n) # probably on different replications
                f_random = np.random.RandomState(seed = rep+5*400*ward_n) # probably on different replications
                g_random = np.random.RandomState(seed = rep+6*400*ward_n) # probably on different replications
                loc_random = np.random.RandomState(seed = rep+7*400*ward_n) # locations
                arena_random = np.random.RandomState(seed = rep+8*400*ward_n) # for bucks arena reroute
                # row[0] is the ward number in 0,1,326
                voting_pop = row[1]
                with open(f"..\\InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}\\r{rep}\\w{ward_n-1}.csv","w+") as f:
                    f.write('ID,priority,ArrivalTime,checkInDur_low,checkInDur_high,serviceDur,submitDur,cleanVoting,cleanBallot,lat,lon,arena_reroute\n')
                    
                    
                # if someone can show up on election day, simulate arrivals
                if voting_pop > 0:
                    time = 0
                    count = 0
                    while time < 780: #13 hours in a day
                        # Arrival rate depends on the time of day
                        proportion_arrive = 0
                        if time < 30*3:
                            proportion_arrive = 0.0693 
                        elif time < 9*30:
                            proportion_arrive = 0.04597
                        elif time < 17*30:
                            proportion_arrive = 0.03033
                        elif time < 21*30:
                            proportion_arrive = 0.03344
#                         elif time <= 26*30:
                        else:
                            proportion_arrive = 0.02798
                        r = voting_pop*vt*(1-ev)*proportion_arrive/30
                        ID = count
                        interarrival_time = a_random.exponential(1/r)
                        arrivalTime = round(time + interarrival_time,3)
                        time += interarrival_time
                        if time <= 780:
                            checkInDuration_low = round(b_random.lognormal(4.070065,0.806992)/60,3)
                            checkInDuration_high = round(h_random.lognormal(4.384035,0.681286)/60,3)
                            serviceDuration = round(c_random.lognormal(1.7042,0.4406),3)
                            submitDuration = round(d_random.triangular(.25,.5,.75),3)
                            cleanVotingDuration = round(f_random.triangular(.25,.5,.75),3)
                            cleanMachineDuration = round(g_random.triangular(.25,.5,.75),3)
                            lat,lon = (0,0) #generateLatLon(ward_n, loc_random)
                            arena = arena_random.uniform()
                            if e_random.random() < fp:
                                priority = 1
                            else:
                                priority = 2
                            count += 1
                            with open(f"..\\InputData\\VoterData\\t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}\\r{rep}\\w{ward_n-1}.csv","a") as f:
                                f.write(f'{ID},{priority},{arrivalTime},{checkInDuration_low},{checkInDuration_high},{serviceDuration},{submitDuration},{cleanVotingDuration},{cleanMachineDuration},{lat},{lon},{arena}\n')
                    cou += 1
    print(f"Finished rep {rep} (t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')})")
