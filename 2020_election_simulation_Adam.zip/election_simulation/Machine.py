'''
Created on Jul 7, 2020

@author: apsch
'''
from numpy import average

machines = []
index = 0

# def newMachine():
#     return Machine()

def create(n):
    for i in range(n):
        machines.append(Machine())
    return

def reset():
    global index
    global machines
    Machine.ID = 0
    machines = []
    index = 0

def getAvailableResource():
    '''
    This returns an available object
    '''
    for m in machines:
        if m.isAvailable():
            return m
    return None

def isAvailableResource():
    for m in machines:
        if m.isAvailable():
            return True
    return False

def getAvgUtil():
    return average([m.uptime/(m.uptime+m.downtime) for m in machines])

class Machine():
    ID = 0
    def __init__(self):
        self.ID = Machine.ID
        Machine.ID += 1
        self.uptime = 0
        self.downtime = 0
        self.timer = 0 # This will start the temporary timing
        self.siezed = False
        
        
    def sieze(self,time):
        if self.siezed:
            raise Exception(f"Machine {self.ID} already siezed.")
        
        # This will add time to the downtime
        self.downtime += time - self.timer
        self.timer = time
        self.siezed = True
        
    def release(self,time):
        if not self.siezed:
            raise Exception(f"Machine {self.ID} not siezed.")
        self.uptime += time - self.timer
        self.timer = time
        self.siezed = False
        
    def isAvailable(self):
        return not self.siezed
        
    def __str__(self):
        return f"M{self.ID}"
    def __repr__(self):
        return f"M{self.ID}"
    def __lt__(self, other):
        return self.ID < other.ID
