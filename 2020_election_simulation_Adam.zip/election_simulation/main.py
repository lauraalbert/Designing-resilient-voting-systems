'''
Created on Jul 8, 2020

@author: apsch
'''

import Voter,Machine,Parameter, CheckIn
import heapq, os
from numpy import average
import math
import random


def readPollingLocations(style, checkIn):
    
    # Using style to determine the information to search
    if style == "A":
        filename = "InputData\\LocationData\\Arena.csv"
    elif style == "D":
        filename = "InputData\\LocationData\\Distributed.csv"
    else:
        raise Exception("No correct style param")
    
    
    wards = {}
    population = {}
    machines = {}
    checkins = {}
    capacities = {}
    
    # read in the arena informations
    with open(filename,"r") as f:
        count = 0
        for row in f.readlines():
            row = row[:-1]
            row = row.split(",")
            if count == 0:
                n_locations = int(row[1])
            # Getting the population of each polling location
            elif count == 1:
                for j in range(n_locations):
                    population[j] = int(row[1+j])
            # Number of machines at each location
            elif count == 3:   
                for j in range(n_locations):
                    machines[j] = int(row[1+j])
            # Number of checkin locations
            elif checkIn == "-" and count == 4:   
                for j in range(n_locations):
                    checkins[j] = int(row[1+j])  
                    
            # Number of checkin locations
            elif checkIn == "+" and count == 5:   
                for j in range(n_locations):
                    checkins[j] = int(row[1+j])  
                      
            # capacity of the location
            elif count == 6:   
                for j in range(n_locations):
                    capacities[j] = int(row[1+j])   
            
            # Which wards are assigned to each polling location
            elif count > 6:
                wards[count - 7] = [int(j) for j in row[1:] if len(j) > 0]
            count += 1  
    
    return n_locations, population, machines, checkins, wards, capacities


def peekTime(pq):
    if len(pq) == 0:
        return 999999
    return pq[0][0]

def nextEvent(pqs):
    '''
    [pqs] is an iterable of priority queues. This method
    will peek at the next event of each queue and return the
    time and event which occurs first and remove it from the priority queue
    '''
    min_time = 999999
    argmin_time = None
    count = 0
    for pq in pqs:
        if peekTime(pq) < min_time:
            argmin_time = pq
            min_time = peekTime(pq)
        count += 1
    
    if argmin_time == None:
        return None
    # This will return just the 
    return heapq.heappop(argmin_time)
 
 
def simulatePPE(capacity,q):
    '''
    This will simulate the movement of the voters throughout the system
    and update the up/downtime of the resources.
    
    It will also track metrics easiest to measure during the system these are
    [0] proportion of time at capacity
    [1] average number of people inside
    [2] average number of people in system at a time
    [3] average number of people in the outside line
    [4] maximum line length
    '''
    
    # This is for tracking metric [0] proportion of time at capacity 
    at_capacity_time = 0
    last_time = 0
    at_capacity = False
    
    # This is for tracking metric [1] the average number of people inside at a time
    persons_inside = 0
    cumulative_num_inside = 0
    
    # This is for tracking metric [2] the average number of people in the system
    persons_system = 0
    cumulative_num_system = 0
    
    # This is for tracking metric [3] the average number of people in the outside line
    cummulative_line_length = 0
    line_length = 0
    
    # This is for tracking metric [4] the maximum line length
    max_line_length = 0
    
    ####
    # Events
    ####
    # (time of event, (event name, voter object, other object (e.g. checkin)))
    arrivals = [(v.arrivalTime, ("arrival",v, None)) for v in Voter.voters] # this is a list of voter arrivals in order of occurance
    finishCheckIn = [] # stores the time at which voters will finish check in
                       # updated throughout simulation
    finishService = [] # stores the time at which each voter will complete their ballot
    finishSubmit = [] # stores the times at which voters will complete submiting 
                      # their ballot
    finishCleaningVote = [] # stores the time at which a voting booth will be clean
#     finishCleaningMachine = [] # stores the time at which a machine will be clean
    
    ####
    # Queues
    ####
    #This is the line for people after they arrive
    checkIn_line = [] # this can be a priority queue if we want
                      # just change priorities when pushing to queue
    
    #This is the line for people after they vote
    submitBallot_line = [] # this can be a priority queue if we want
                           # just change priorities when pushing to queue
    
    next_event = nextEvent((arrivals,finishCheckIn,finishService,finishSubmit,finishCleaningVote)) # Gets the first event   [,finishCleaningMachine]    
    
    # while there are events, updating the system    
    while next_event != None: # or len(checkIn_line) > 0 or len(submitBallot_line) > 0
        event_time = next_event[0]
        event_name = next_event[1][0]
        voter = next_event[1][1]
        resource = next_event[1][2]
#         if event_time > 9.741:
#             input()
        
        ####
        # Updating metrics 
        ####
        # [0] proportion of time at capacity
        if at_capacity: #checking if was at capacity after last round
            at_capacity_time += event_time - last_time
        
        # [1] number of people inside
        cumulative_num_inside += persons_inside*(event_time-last_time)
        
        # [2] number of people in the system
        cumulative_num_system += persons_system*(event_time-last_time)
        
        # [3] length of outside line
        cummulative_line_length += line_length*(event_time-last_time)
        
        # looks at the event name and decides what to do with the event
        if event_name == "arrival": # Voter arrives
            at = voter.arrivalTime
            # since they arrived, we now add them to the check in line
            # the value here is [0] priority [1] arrival time [2] voter
            
            #####
            ## !!!!! HERE FOR PRIORITY QUEUE !!!!!!
            #####
            
            if q == "fifo":
                heapq.heappush(checkIn_line,(0,at,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            elif q == "pq":
                heapq.heappush(checkIn_line,(voter.priority,at,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            else:
                raise Exception(f"unknown queuing style {q}")
            
        elif event_name == "f_checkin": # Checkin is finished
            # We release the checkin resource
            resource.release(event_time)
            
            # They now start voting and sieze no resources
            voter.startService = event_time
            finish_voting_time = event_time + voter.serviceDuration
            heapq.heappush(finishService,(finish_voting_time,("voted",voter,None)))
            
        elif event_name == "voted":
            
            # we add them to the submitted queue
            # the value here is [0] priority [1] arrival time [2] voter
            
            #####
            ## !!!!! HERE FOR PRIORITY QUEUE !!!!!!
            #####
            
            if q == "fifo":
                heapq.heappush(submitBallot_line,(0,event_time,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            elif q == "pq":
                heapq.heappush(submitBallot_line,(voter.priority,event_time,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            else:
                raise Exception(f"unknown queuing style {q}")
            
            
            heapq.heappush(finishCleaningVote,(event_time+voter.cleanVoteDuration,("cleanedVote",None,None)))
            
        elif event_name == "cleanedVote":
            # All we want to do is remove it from the queue since there
            # are no voting booth objects
            pass
        
        elif event_name == "submitted":
            # voter is finished with journey
            voter.finishTime = event_time
            # machine starts getting cleaned
#             heapq.heappush(finishCleaningMachine,(event_time+voter.cleanMachineDuration,("cleanedMachine",None,resource)))
            resource.release(event_time)
#         elif event_name == "cleanedMachine":  
#             resource.release(event_time) # voting machine is released
            
        
        else:
            raise Exception(f"unknown event found {event_name}")
        
        ###
        # If there are people in any of the queues and available machines
        # downstream, then we sieze those machines and remove from queue
        ###
        
#         print(event_time,next_event)
#         print("#"*10, "Before Queue Update")
#         print("Arrivals Remaining", len(arrivals),arrivals[:5])#,arrivals
#         print("Checkin Line", len(checkIn_line), checkIn_line)
#         print("Upcoming Checkin Finishes",len(finishCheckIn), finishCheckIn)
#         print("Upcoming Service Finishes",len(finishService),finishService)
#         print("SubmitLine",len(submitBallot_line),submitBallot_line)
#         print("Upcoming Ballot Finishes",len(finishSubmit),finishSubmit)
#         print("#"*10, "After Queue Update")
        
        # If people waiting to submit ballot and there are machines available
        while len(submitBallot_line) > 0 and Machine.isAvailableResource():
            next_item = heapq.heappop(submitBallot_line)
            voter = next_item[2]
            voter.startSubmit = event_time
            # They start checking in
            m = Machine.getAvailableResource()
            m.sieze(event_time)
            heapq.heappush(finishSubmit,(event_time+voter.submitDuration,("submitted",voter,m)))
            
        # If people waiting to check in and there are people who can
        # check them in. We also limit the number of people inside
        persons_inside = len(finishCheckIn)+len(finishService)+len(submitBallot_line)+len(finishSubmit)
        while len(checkIn_line) > 0 and CheckIn.isAvailableResource() and persons_inside < capacity - len(finishCleaningVote):
            next_item = heapq.heappop(checkIn_line)
#             print("NI",next_item)
            voter = next_item[2]
            voter.startCheckIn = event_time
            # They start checking in
            ci = CheckIn.getAvailableResource()
            ci.sieze(event_time)
            heapq.heappush(finishCheckIn,(event_time+voter.checkInDuration,("f_checkin",voter,ci)))
            persons_inside = len(finishCheckIn)+len(finishService)+len(submitBallot_line)+len(finishSubmit)
        
        
#         print("Arrivals Remaining", len(arrivals),arrivals[:5])#,arrivals
#         print("Checkin Line", len(checkIn_line), checkIn_line)
#         print("Upcoming Checkin Finishes",len(finishCheckIn), finishCheckIn)
#         print("Upcoming Service Finishes",len(finishService),finishService)
#         print("SubmitLine",len(submitBallot_line),submitBallot_line)
#         print("Upcoming Ballot Finishes",len(finishSubmit),finishSubmit)
#         input()
        
#         sleep(.15)
#        
        if len(checkIn_line) > max_line_length:
            max_line_length = len(checkIn_line)
        
        # Updating values for next round
        if persons_inside < capacity:
            at_capacity = False
        else:
            at_capacity = True
        
        persons_system = len(checkIn_line)+len(finishCheckIn)+len(finishService)+len(submitBallot_line)+len(finishSubmit)

        last_time = event_time
        # Finding next event
        next_event = nextEvent((arrivals,finishCheckIn,finishService,finishSubmit,finishCleaningVote))  #[,finishCleaningMachine]
        line_length = len(checkIn_line)
    
    # We are siezing the objects to make the utilization correct
    for m in Machine.machines:
        m.sieze(event_time)
    for c in CheckIn.checkIns:
        c.sieze(event_time)
        
#     print(at_capacity_time/event_time)
#     print(cumulative_num_inside/event_time)
#     print(cumulative_num_system/event_time)
#     print(cummulative_line_length/event_time)
    return at_capacity_time/last_time, cumulative_num_inside/event_time, cumulative_num_system/event_time,cummulative_line_length/event_time, max_line_length

def simulateNoPPE(capacity,q):
    '''
    This will simulate the movement of the voters throughout the system
    and update the up/downtime of the resources.
    
    It will also track metrics easiest to measure during the system these are
    [0] proportion of time at capacity
    [1] average number of people inside
    [2] average number of people in system at a time
    [3] average number of people in the outside line
    [4] maximum line length
    '''
    
    # This is for tracking metric [0] proportion of time at capacity 
    at_capacity_time = 0
    last_time = 0
    at_capacity = False
    
    # This is for tracking metric [1] the average number of people inside at a time
    persons_inside = 0
    cumulative_num_inside = 0
    
    # This is for tracking metric [2] the average number of people in the system
    persons_system = 0
    cumulative_num_system = 0
    
    # This is for tracking metric [3] the average number of people in the outside line
    cummulative_line_length = 0
    line_length = 0
    
    # This is for tracking metric [4] the maximum line length
    max_line_length = 0
    
    ####
    # Events
    ####
    # (time of event, (event name, voter object, other object (e.g. checkin)))
    arrivals = [(v.arrivalTime, ("arrival",v, None)) for v in Voter.voters] # this is a list of voter arrivals in order of occurance
    finishCheckIn = [] # stores the time at which voters will finish check in
                       # updated throughout simulation
    finishService = [] # stores the time at which each voter will complete their ballot
    finishSubmit = [] # stores the times at which voters will complete submiting 
                      # their ballot
    
    ####
    # Queues
    ####
    #This is the line for people after they arrive
    checkIn_line = [] # this can be a priority queue if we want
                      # just change priorities when pushing to queue
    
    #This is the line for people after they vote
    submitBallot_line = [] # this can be a priority queue if we want
                           # just change priorities when pushing to queue
    
    next_event = nextEvent((arrivals,finishCheckIn,finishService,finishSubmit)) # Gets the first event
    
    # while there are events, updating the system    
    while next_event != None: # or len(checkIn_line) > 0 or len(submitBallot_line) > 0
        event_time = next_event[0]
        event_name = next_event[1][0]
        voter = next_event[1][1]
        resource = next_event[1][2]
#         if event_time > 9.741:
#             input()

        ####
        # Updating metrics 
        ####
        # [0] proportion of time at capacity
        if at_capacity: #checking if was at capacity after last round
            at_capacity_time += event_time - last_time
        
        # [1] number of people inside
        cumulative_num_inside += persons_inside*(event_time-last_time)
        
        # [2] number of people in the system
        cumulative_num_system += persons_system*(event_time-last_time)
        
        # [3] length of outside line
        cummulative_line_length += line_length*(event_time-last_time)
        
        # looks at the event name and decides what to do with the event
        if event_name == "arrival": # Voter arrives
            at = voter.arrivalTime
            # since they arrived, we now add them to the check in line
            # the value here is [0] priority [1] arrival time [2] voter
            
            #####
            ## !!!!! HERE FOR PRIORITY QUEUE !!!!!!
            #####
            
            if q == "fifo":
                heapq.heappush(checkIn_line,(0,at,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            elif q == "pq":
                heapq.heappush(checkIn_line,(voter.priority,at,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            else:
                raise Exception(f"unknown queuing style {q}")
        
        elif event_name == "f_checkin": # Checkin is finished
            # We release the checkin resource
            resource.release(event_time)
            
            # They now start voting and sieze no resources
            voter.startService = event_time
            finish_voting_time = event_time + 4/6*voter.serviceDuration
            ### NO PPE RESULTS IN LOWER VOTING TIME
            heapq.heappush(finishService,(finish_voting_time,("voted",voter,None)))
            
        elif event_name == "voted":
            
            # we add them to the submitted queue
            # the value here is [0] priority [1] arrival time [2] voter
            
            #####
            ## !!!!! HERE FOR PRIORITY QUEUE !!!!!!
            #####
            
            if q == "fifo":
                heapq.heappush(submitBallot_line,(0,event_time,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            elif q == "pq":
                heapq.heappush(submitBallot_line,(voter.priority,event_time,voter)) # everyone has some priority, change 0 to voter.priority for priority q
            else:
                raise Exception(f"unknown queuing style {q}")
            
        elif event_name == "submitted":
            # voter is finished with journey
            voter.finishTime = event_time
            # machine starts getting cleaned
            resource.release(event_time) # voting machine is released
        
        else:
            raise Exception(f"unknown event found {event_name}")
        
        ###
        # If there are people in any of the queues and available machines
        # downstream, then we sieze those machines and remove from queue
        ###
        
#         print(event_time,next_event)
#         print("#"*10, "Before Queue Update")
#         print("Arrivals Remaining", len(arrivals),arrivals[:5])#,arrivals
#         print("Checkin Line", len(checkIn_line), checkIn_line)
#         print("Upcoming Checkin Finishes",len(finishCheckIn), finishCheckIn)
#         print("Upcoming Service Finishes",len(finishService),finishService)
#         print("SubmitLine",len(submitBallot_line),submitBallot_line)
#         print("Upcoming Ballot Finishes",len(finishSubmit),finishSubmit)
#         print("#"*10, "After Queue Update")
        
        # If people waiting to submit ballot and there are machines available
        while len(submitBallot_line) > 0 and Machine.isAvailableResource():
            next_item = heapq.heappop(submitBallot_line)
            voter = next_item[2]
            voter.startSubmit = event_time
            # They start checking in
            m = Machine.getAvailableResource()
            m.sieze(event_time)
            heapq.heappush(finishSubmit,(event_time+voter.submitDuration,("submitted",voter,m)))
            
        # If people waiting to check in and there are people who can
        # check them in. We also limit the number of people inside
        persons_inside = len(finishCheckIn)+len(finishService)+len(submitBallot_line)+len(finishSubmit)
        while len(checkIn_line) > 0 and CheckIn.isAvailableResource() and persons_inside < capacity:
            next_item = heapq.heappop(checkIn_line)
#             print("NI",next_item)
            voter = next_item[2]
            voter.startCheckIn = event_time
            # They start checking in
            ci = CheckIn.getAvailableResource()
            ci.sieze(event_time)
            heapq.heappush(finishCheckIn,(event_time+voter.checkInDuration,("f_checkin",voter,ci)))
            persons_inside = len(finishCheckIn)+len(finishService)+len(submitBallot_line)+len(finishSubmit)
        
        
#         print("Arrivals Remaining", len(arrivals),arrivals[:5])#,arrivals
#         print("Checkin Line", len(checkIn_line), checkIn_line)
#         print("Upcoming Checkin Finishes",len(finishCheckIn), finishCheckIn)
#         print("Upcoming Service Finishes",len(finishService),finishService)
#         print("SubmitLine",len(submitBallot_line),submitBallot_line)
#         print("Upcoming Ballot Finishes",len(finishSubmit),finishSubmit)
#         input()
        
#         sleep(.15)
#         print(f"{round(event_time,2)} ({cumulative_num_inside/event_time}):{'a'*len(checkIn_line)}|{'c'*len(finishCheckIn)}|{'v'*len(finishService)}|{'w'*len(submitBallot_line)}|{'s'*len(finishSubmit)}")
        if len(checkIn_line) > max_line_length:
            max_line_length = len(checkIn_line)
        
        # Updating values for next round
        if persons_inside < capacity:
            at_capacity = False
        else:
            at_capacity = True
        
        persons_system = len(checkIn_line)+len(finishCheckIn)+len(finishService)+len(submitBallot_line)+len(finishSubmit)

        last_time = event_time
        # Finding next event
        next_event = nextEvent((arrivals,finishCheckIn,finishService,finishSubmit))
        line_length = len(checkIn_line)
    
    # We are siezing the objects to make the utilization correct
    for m in Machine.machines:
        m.sieze(event_time)
    for c in CheckIn.checkIns:
        c.sieze(event_time)
        
#     print(at_capacity_time/event_time)
#     print(cumulative_num_inside/event_time)
#     print(cumulative_num_system/event_time)
#     print(cummulative_line_length/event_time)
    return at_capacity_time/last_time, cumulative_num_inside/event_time, cumulative_num_system/event_time,cummulative_line_length/event_time, max_line_length  

 
        
def simulateLocation(capacity, PPE,q):
    if PPE == "-":
        return simulateNoPPE(capacity,q)
    elif PPE == "+":
        return simulatePPE(capacity,q)
    else:
        raise Exception(f"{PPE} not known PPE designation")

def main():
    
    ###
    # Iterating through each of the levels within our
    # factorial design
    ###
    q = "fifo"
    PPE = "-" #"+"   # if we add time for ppe at checkin and cleaning time (+ is higher ppe time)
    cap_scale = 1 # 0.5  # if we have a high or low capacity at each location
    fp = Parameter.priority_frac[0] # The proportion of in person voter who are high risk
    num_checkIns = "+" # whether we have high or low number of checkin booths
    machine_div = [1]
    checkin_div = [1]
    for m in machine_div:
        for c in checkin_div:
            for vt in Parameter.voter_turnout: # the turnout of voting age pop
                for ev in Parameter.early_voting: # the percent of turnout which vote early
                    for style in Parameter.style: # whether arena style or distributed
                        if not os.path.isfile(f"Results\\M{m}C{c}+PPE{PPE}CAP{cap_scale}CHECKIN{num_checkIns}+t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}.csv"):
                            with open(f"Results\\M{m}C{c}+PPE{PPE}CAP{cap_scale}CHECKIN{num_checkIns}+t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}.csv","w+") as f:
                                h = "Style,Rep,NumVoters,p_MachineUtil,p_CheckInUtil,v_waitTime, v_timeInside, v_sojournTime, v_15minWait, v_30minWait,p_waitTime,p_sojournTime,p_lineLength,p_15minWait,p_30minWait,p_votersInside,p_votersSystem,p_timeAtCap"
                                h += ",v_maxwaitTime, v_maxtimeInside, v_maxsojournTime, v_max15minWait, v_max30minWait,p_maxwaitTime,p_maxsojournTime,p_maxlineLength,p_max15minWait,p_max30minWait,p_maxvotersInside,p_maxvotersSystem,p_maxtimeAtCap,v_priority1Wait,v_priority2Wait,v_priority1sojourn,v_priority2sojourn\n"
                                f.write(h)
                        
                        for rep in range(Parameter.n_replications):
                            # Reads in the polling locations
                            n_locations, population, machines, checkins, wards, capacities = readPollingLocations(style,num_checkIns)
                            
                            # need to decide if averaging by precinct or by machine
                            machine_utilization = []
        #                         num_machines = 0
                            
                            # need to decide if averaging by precinct or by machine
                            checkin_utilization = []
        #                         num_checkin = 0
                            
                            # voter info
                            v_wait = 0
                            v_Tinside = 0
                            v_sojourn = 0
                            v_15 = 0
                            v_30 = 0
                            v_pri1Wait = 0
                            v_pri2Wait = 0
                            v_pri1Sojourn = 0
                            v_pri2Sojourn = 0
                            v_max_wait = 0
                            v_max_Tinside = 0
                            v_max_sojourn = 0
                            v_max_15 = 0
                            v_max_30 = 0
                            number_of_voters = 0
                            
                            #polling location info
                            p_wait = []
                            p_line = []
                            p_max_line = 0
                            p_sojourn = []
                            p_15 = []
                            p_30 = []
                            p_inside = []
                            p_system = []
                            p_capacity = []
        #                         p_max_wait = 0
        #                         p_max_line = 0
        #                         p_max_sojourn = 0
        #                         p_max_15 = 0
        #                         p_max_60 = 0
        #                         p_max_inside = 0
        #                         p_max_system = 0
        #                         p_max_capacity = 0
                           
                            
                            # We have to run the simulation for each polling location
                            for loc in range(n_locations):
                                # Reading in the voters for the wards of interest
                                Voter.readVoters(wards[loc],rep,info = (vt,ev,fp,PPE))
                                Machine.create(math.ceil(machines[loc]*m)) # Creating appropriate number of wards     machines[loc]
                                CheckIn.create(math.ceil(checkins[loc]*c)) # Creating appropriate number of wards       math.ceil(checkins[loc])
        #                                 print("C",c,math.ceil(checkins[loc]*c))
                                ####
                                # SIMULATING
                                ####
                                capacity = cap_scale*population[loc]*(6.0573+1+.5)/13/60 # Calculates the capactiy
                                capacity = math.ceil(capacity)
                                prop_capacity, people_inside, people_system, outside_line, max_line = simulateLocation(capacity,PPE,q) #capacities[loc]
        
                                # Getting the results for different metrics
                                # system
                                p_wait.append(Voter.getAvgWait())
                                p_line.append(outside_line)
                                if max_line > p_max_line:
                                    p_max_line = max_line
                                p_sojourn.append(Voter.getAvgSojourn())
                                p_15.append(Voter.getPropTmin(15))
                                p_30.append(Voter.getPropTmin(30))
                                p_inside.append(people_inside)
                                p_system.append(people_system)
                                p_capacity.append(prop_capacity)
                                    
                                # Voter metrics
                                number_of_voters += len(Voter.voters)
                                
                                v_wait += Voter.getAvgWait()*len(Voter.voters)
                                v_Tinside += Voter.getAvgTimeInside()*len(Voter.voters)
                                v_sojourn += Voter.getAvgSojourn()*len(Voter.voters)
                                v_15 += Voter.getPropTmin(15)*len(Voter.voters)
                                v_30 += Voter.getPropTmin(30)*len(Voter.voters)
                                
                                if Voter.getMaxWait() > v_max_wait:
                                    v_max_wait = Voter.getMaxWait()
                                if Voter.getMaxTimeInside() > v_max_Tinside:
                                    v_max_Tinside = Voter.getMaxTimeInside()
                                if Voter.getMaxSojourn() > v_max_sojourn:
                                    v_max_sojourn = Voter.getMaxSojourn()
                                if Voter.getMaxPropTmin(15) > v_max_15:
                                    v_max_15 = Voter.getMaxPropTmin(15)
                                if Voter.getMaxPropTmin(30) > v_max_30:
                                    v_max_30 = Voter.getMaxPropTmin(30)
                                
                                v_pri1Wait += Voter.getAvgWait(1)*len(Voter.voters)
                                v_pri2Wait += Voter.getAvgWait(2)*len(Voter.voters)
                                v_pri1Sojourn += Voter.getAvgSojourn(1)*len(Voter.voters)
                                v_pri2Sojourn += Voter.getAvgSojourn(2)*len(Voter.voters)
                                
                                # Machine utilization
        #                             num_machines += len(Machine.machines)
                                machine_utilization.append(Machine.getAvgUtil())
        #                         if Machine.getAvgUtil() > .995:
        #                             print(loc, Machine.getAvgUtil(), "Machines",machines[loc], Voter.getAvgWait())
                                # Checkin Utilization
        #                             num_checkin += len(CheckIn.checkIns)
                                checkin_utilization.append(CheckIn.getAvgUtil())
        #                         if CheckIn.getAvgUtil() > .995:
        #                             print(loc, CheckIn.getAvgUtil(), "Checkin",checkins[loc], Voter.getAvgWait())
                                
                                Machine.reset()
                                CheckIn.reset()
                                Voter.reset()
                            
                            # Calculating the results for each replication
                            results = (average(machine_utilization), # average machine util by polling loc
                                       average(checkin_utilization), # average checkin util by polling loc
                                       v_wait/number_of_voters, 
                                       v_Tinside/number_of_voters, 
                                       v_sojourn/number_of_voters, 
                                       v_15/number_of_voters, 
                                       v_30/number_of_voters, 
                                       average(p_wait),
                                       average(p_sojourn),
                                       average(p_line),
                                       average(p_15),
                                       average(p_30),
                                       average(p_inside),
                                       average(p_system),
                                       average(p_capacity),
                                       v_max_wait,
                                       v_max_Tinside,
                                       v_max_sojourn,
                                       v_max_15,
                                       v_max_30,
                                       max(p_wait),
                                       max(p_sojourn),
                                       p_max_line,
                                       max(p_15),
                                       max(p_30),
                                       max(p_inside),
                                       max(p_system),
                                       max(p_capacity),
                                       v_pri1Wait/number_of_voters,
                                       v_pri2Wait/number_of_voters,
                                       v_pri1Sojourn/number_of_voters,
                                       v_pri2Sojourn/number_of_voters
                                       )
                                       
                            stri = f"{style},{rep},{number_of_voters}"
                            for r in results:
                                stri += ","
                                stri += str(round(r,3))
                            stri+="\n"
                            with open(f"Results\\M{m}C{c}+PPE{PPE}CAP{cap_scale}CHECKIN{num_checkIns}+t{str(vt*100).replace('.',',')}_e{str(ev*100).replace('.',',')}_p{str(fp*100).replace('.',',')}.csv","a") as f:
                                f.write(stri)
                            print(f"Completed {style} rep {rep}")
                    # Here 1    
if __name__ == "__main__":
    # execute only if run as a script
    main()